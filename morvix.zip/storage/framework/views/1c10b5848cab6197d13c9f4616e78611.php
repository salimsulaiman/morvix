<aside class="hidden md:block bg-white rounded-3xl shadow p-5 space-y-6">
    <form method="GET" action="<?php echo e(url()->current()); ?>" class="space-y-3">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = request()->except(['categories', 'features', 'transmissions', 'fuel_types', 'min_price', 'max_price', 'page']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(is_array($value)): ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $value; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <input type="hidden" name="<?php echo e($key); ?>[]" value="<?php echo e($v); ?>">
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <?php else: ?>
                <input type="hidden" name="<?php echo e($key); ?>" value="<?php echo e($value); ?>">
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <h2 class="text-sm font-bold text-slate-700 border-b border-lime-200 pb-2">
            Filter <?php echo e($type === 'car' ? 'Mobil' : 'Motor'); ?>

        </h2>

        <div>
            <h3 class="text-sm font-semibold text-slate-600 mb-2 uppercase tracking-wide">Kategori</h3>
            <div class="space-y-1 text-slate-700">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <label class="flex items-center gap-2">
                        <input type="checkbox" name="categories[]" value="<?php echo e($category->id); ?>"
                            <?php if(in_array($category->id, request('categories', []))): echo 'checked'; endif; ?> class="text-lime-600 focus:ring-lime-400">
                        <?php echo e($category->name); ?>

                    </label>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </div>

        <div>
            <h3 class="text-sm font-semibold text-slate-600 mb-2 uppercase tracking-wide">Transmisi</h3>
            <div class="space-y-1 text-slate-700">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = ['manual', 'automatic']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transmission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <label class="flex items-center gap-2">
                        <input type="checkbox" name="transmissions[]" value="<?php echo e($transmission); ?>"
                            <?php if(in_array($transmission, request('transmissions', []))): echo 'checked'; endif; ?> class="text-lime-600 focus:ring-lime-400">
                        <?php echo e(ucfirst($transmission)); ?>

                    </label>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </div>

        <div>
            <h3 class="text-sm font-semibold text-slate-600 mb-2 uppercase tracking-wide">Bahan Bakar</h3>
            <div class="space-y-1 text-slate-700">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = ['gasoline', 'diesel', 'electric']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fuel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <label class="flex items-center gap-2">
                        <input type="checkbox" name="fuel_types[]" value="<?php echo e($fuel); ?>"
                            <?php if(in_array($fuel, request('fuel_types', []))): echo 'checked'; endif; ?> class="text-lime-600 focus:ring-lime-400">
                        <?php echo e(ucfirst($fuel)); ?>

                    </label>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </div>

        <div>
            <h3 class="text-sm font-semibold text-slate-600 mb-2 uppercase tracking-wide">Fitur Tambahan</h3>
            <div class="space-y-1 text-slate-700">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <label class="flex items-center gap-2">
                        <input type="checkbox" name="features[]" value="<?php echo e($feature->id); ?>"
                            <?php if(in_array($feature->id, request('features', []))): echo 'checked'; endif; ?> class="text-lime-600 focus:ring-lime-400">
                        <?php echo e($feature->name); ?>

                    </label>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </div>

        <div>
            <h3 class="text-sm font-semibold text-slate-600 mb-2 uppercase tracking-wide">Rentang Harga</h3>

            <div class="space-y-2">
                <div class="flex justify-between text-xs text-slate-500">
                    <span>Rp <span x-text="minPrice.toLocaleString()"></span></span>
                    <span>Rp <span x-text="maxPrice.toLocaleString()"></span></span>
                </div>

                <input type="range" x-model="minPrice" :min="rangeMin" :max="rangeMax"
                    :step="10000" class="w-full accent-lime-500">
                <input type="range" x-model="maxPrice" :min="rangeMin" :max="rangeMax"
                    :step="10000" class="w-full accent-lime-500">

                <input type="hidden" name="min_price" :value="minPrice">
                <input type="hidden" name="max_price" :value="maxPrice">
            </div>
        </div>

        <button type="submit"
            class="w-full bg-lime-600 text-white rounded-lg py-2 mt-3 hover:bg-lime-700 transition shadow-md">
            Terapkan Filter
        </button>
    </form>
</aside>
<?php /**PATH C:\laragon\www\morvix\resources\views/components/vehicle-filter.blade.php ENDPATH**/ ?>