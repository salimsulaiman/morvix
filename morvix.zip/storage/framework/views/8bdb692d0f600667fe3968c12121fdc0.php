
<?php $__env->startSection('content'); ?>
    <div class="flex-1 p-8 w-full max-w-7xl mx-auto py-16">
        <div class="flex items-center justify-between mb-6 mt-24">
            <div>
                <h1 class="text-2xl font-semibold text-slate-800">
                    Order History
                </h1>
                <p class="text-slate-500 text-sm">
                    Manage your rental orders
                </p>
            </div>
        </div>

        <?php
            $filters = [
                'all' => 'All',
                'PENDING' => 'Pending',
                'PAID' => 'Paid',
                'EXPIRED' => 'Expired',
                'REFUNDED' => 'Refunded',
            ];

            $activeStatus = request('status', 'all');
        ?>

        <div class="flex flex-col gap-3 mb-4 md:flex-row md:items-center md:justify-between">
            <!-- Search -->
            <form method="GET" action="<?php echo e(url()->current()); ?>" class="relative w-full md:w-64">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(request('status')): ?>
                    <input type="hidden" name="status" value="<?php echo e(request('status')); ?>">
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                <input type="text" name="search" value="<?php echo e(request('search')); ?>" placeholder="Cari kode booking..."
                    class="w-full rounded-full border border-slate-200 pl-10 pr-4 py-2 text-sm text-slate-700
               focus:border-lime-500 focus:ring-lime-500">

                <button type="submit" class="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-lime-600">
                    <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M21 21l-4.35-4.35m1.85-5.65a7 7 0 11-14 0 7 7 0 0114 0z" />
                    </svg>
                </button>
            </form>

            <!-- Filters -->
            <div class="flex gap-2 overflow-x-auto scrollbar-hide pb-1">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $filters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e($value === 'all'
                        ? route('orders.index', request()->only('search'))
                        : route('orders.index', ['status' => $value] + request()->only('search'))); ?>"
                        class="whitespace-nowrap px-4 py-2 rounded-full text-xs font-medium transition
                <?php echo e($activeStatus === $value
                    ? 'bg-lime-600 text-white'
                    : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'); ?>">
                        <?php echo e($label); ?>

                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </div>

        <div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-x-auto">
            <table class="w-full min-w-[700px]">
                <thead class="bg-slate-50 text-slate-600 text-sm">
                    <tr>
                        <th class="px-6 py-4 text-left">Invoice</th>
                        <th class="px-6 py-4 text-left">Customer</th>
                        <th class="px-6 py-4 text-left">Vehicle</th>
                        <th class="px-6 py-4 text-left">Rental</th>
                        <th class="px-6 py-4 text-left">Payment</th>
                        <th class="px-6 py-4 text-right">Action</th>
                    </tr>
                </thead>

                <tbody class="divide-y divide-slate-100">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $paymentStatus = optional($order->payment)->status ?? 'pending';

                            $paymentClass = [
                                'PAID' => 'bg-lime-100 text-lime-700',
                                'SETTLED' => 'bg-lime-100 text-lime-700',
                                'PENDING' => 'bg-yellow-100 text-yellow-700',
                                'EXPIRED' => 'bg-red-100 text-red-700',
                            ];

                            $rentalClass = [
                                'booked' => 'bg-slate-100 text-slate-700',
                                'ongoing' => 'bg-blue-100 text-blue-700',
                                'completed' => 'bg-lime-100 text-lime-700',
                                'cancelled' => 'bg-red-100 text-red-700',
                            ];
                        ?>

                        <tr class="hover:bg-slate-50 text-sm">
                            <td class="px-6 py-4 font-medium text-slate-800">
                                <?php echo e($order->booking_code); ?>

                            </td>

                            <td class="px-6 py-4">
                                <div class="font-medium text-slate-800">
                                    <?php echo e($order->user->name); ?>

                                </div>
                                <div class="text-xs text-slate-500">
                                    <?php echo e($order->user->email); ?>

                                </div>
                            </td>

                            <td class="px-6 py-4 text-slate-700">
                                <?php echo e($order->vehicle->vehicleModel->name); ?>

                            </td>

                            <td class="px-6 py-4">
                                <span
                                    class="px-3 py-1 rounded-full text-xs font-medium
                        <?php echo e($rentalClass[$order->rental_status]); ?>">
                                    <?php echo e(ucfirst($order->rental_status)); ?>

                                </span>
                            </td>

                            <td class="px-6 py-4">
                                <span
                                    class="px-3 py-1 rounded-full text-xs font-medium
                        <?php echo e($paymentClass[$paymentStatus]); ?>">
                                    <?php echo e(ucfirst($paymentStatus)); ?>

                                </span>
                            </td>

                            <td class="px-6 py-4 text-right">
                                <a href="<?php echo e(route('orders.show', $order->booking_code)); ?>"
                                    class="inline-flex items-center justify-center text-slate-500 hover:text-slate-700 h-8 w-8 rounded-md hover:bg-slate-300 transition-colors duration-150 ease-in-out">
                                    <i data-feather="eye" class="h-5 w-5"></i>
                                </a>
                            </td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="mt-6">
            <?php echo e($orders->links()); ?>

        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\morvix\resources\views/pages/profile/order/index.blade.php ENDPATH**/ ?>