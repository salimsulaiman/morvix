<div class="fixed bottom-0 left-0 right-0 z-40 bg-slate-900 lg:hidden">
    <div class="flex justify-evenly px-4 py-4 items-center">

        <a href="<?php echo e(route('home.index')); ?>"
            class="flex w-full items-center justify-center text-xs font-medium gap-2 transition
           <?php echo e(request()->routeIs('home.*')
               ? 'bg-lime-800 px-4 py-3 rounded-full text-lime-100'
               : 'flex-col text-slate-400 hover:text-lime-300'); ?>">
            <i data-feather="home" class="w-5 h-5 shrink-0"></i>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(request()->routeIs('home.*')): ?>
                <span>Beranda</span>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </a>

        <a href="<?php echo e(route('cars.index')); ?>"
            class="flex w-full items-center justify-center text-xs font-medium gap-2 transition
           <?php echo e(request()->routeIs('cars.*')
               ? 'bg-lime-800 px-4 py-3 rounded-full text-lime-100'
               : 'flex-col text-slate-400 hover:text-lime-300'); ?>">
            <i data-feather="truck" class="w-5 h-5 shrink-0"></i>
            <?php if(request()->routeIs('cars.*')): ?>
                <span>Mobil</span>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </a>

        <a href="<?php echo e(route('motorcycles.index')); ?>"
            class="flex w-full items-center justify-center text-xs font-medium gap-2 transition
           <?php echo e(request()->routeIs('motorcycles.*')
               ? 'bg-lime-800 px-4 py-3 rounded-full text-lime-100'
               : 'flex-col text-slate-400 hover:text-lime-300'); ?>">
            <i data-feather="zap" class="w-5 h-5 shrink-0"></i>
            <?php if(request()->routeIs('motorcycles.*')): ?>
                <span>Motor</span>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </a>

        <a href="#"
            class="flex w-full items-center justify-center text-xs font-medium gap-2 transition
           <?php echo e(request()->routeIs('layanan.*')
               ? 'bg-lime-800 px-4 py-3 rounded-full text-lime-100'
               : 'flex-col text-slate-400 hover:text-lime-300'); ?>">
            <i data-feather="grid" class="w-5 h-5 shrink-0"></i>
            <?php if(request()->routeIs('layanan.*')): ?>
                <span>Layanan</span>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </a>

        <a href="<?php echo e(route('profile.index')); ?>"
            class="flex w-full items-center justify-center text-xs font-medium gap-2 transition
           <?php echo e(request()->routeIs('profile.*')
               ? 'bg-lime-800 px-4 py-3 rounded-full text-lime-100'
               : 'flex-col text-slate-400 hover:text-lime-300'); ?>">
            <i data-feather="user" class="w-5 h-5 shrink-0"></i>
            <?php if(request()->routeIs('profile.*')): ?>
                <span>Profile</span>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </a>
    </div>
</div>
<?php /**PATH C:\laragon\www\morvix\resources\views/partials/bottom-nav.blade.php ENDPATH**/ ?>